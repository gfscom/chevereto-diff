<div class="list-item fixed-size c%COLUMN_SIZE_USER% gutter-margin-right-bottom" data-type="user">
	<a href="%USER_URL%" class="list-item-image fixed-size" %tpl_list_item/user_background_image%>
		<div class="list-item-avatar-cover image-container">
		%tpl_list_item/user_cover_empty%
		%tpl_list_item/user_cover_image%
		</div>
	</a>
	<div class="list-item-desc">
		<div class="list-item-desc-title">
			<a class="list-item-desc-title-link" href="%USER_URL%">%USER_NAME%</a>
			<div class="list-item-from font-size-small">%USER_USERNAME%</div>
		</div>
		<div class="position-absolute right-10 bottom-10 text-align-right">%USER_IMAGE_COUNT%<span class="fas fa-image margin-left-5"></span></div>
	</div>
</div>