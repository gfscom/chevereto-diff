<div class="list-item-like" data-action="like">
	<span class="btn-icon btn-like btn-liked fas fa-heart"></span>
	<span class="btn-icon btn-like btn-unliked far fa-heart"></span>
</div>