<?php

/* --------------------------------------------------------------------

  Chevereto
  https://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
            <inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.

  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  https://chevereto.com/license

  --------------------------------------------------------------------- */

/**
 * This is an internal redirector intented to avoid spammers trying to get some
 * SEO juice by putting links all over your Chevereto website.
 *
 * It also avoids spammers to use this redirector to hang spam and whatnot in
 * third-party websites (auth_token stuff).
 *
 * The redirection is only issued if the URL was generedated by CHV\crypt().
 */
$route = function ($handler) {
    $encrypted = $_GET['to'];
    $url = CHV\decryptString($encrypted);
    $validations = [
        filter_var($url, FILTER_VALIDATE_URL) != false,
        $handler::checkAuthToken($_GET['auth_token']) != false
    ];
    if (in_array(false, $validations)) {
        return $handler->issue404();
    }
    G\redirect($url, 302);
};
