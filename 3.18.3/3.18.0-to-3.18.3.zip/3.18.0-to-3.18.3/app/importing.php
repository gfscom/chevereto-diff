<?php
/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
            <inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.

  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */

namespace CHV;

use Exception;
use G;

$threadID = getenv('THREAD_ID');
if (!isset($threadID)) {
    die("Missing thread id (int)\n");
}
$loop = 1;
do {
    Import::refresh();
    $jobs = Import::autoJobs();
    if ($jobs === []) {
        echo "No jobs left.\n";
        die(0);
    }
    $id = $jobs[0]['import_id'];
    $import = new Import();
    $import->id = $id;
    $import->thread = (int) $threadID;
    $import->get();
    if ($import->isLocked()) {
        $import->edit(['status' => 'paused']);
        echo "Import file-locked for job id #$id\n";
    } else {
        $import->process();
        echo "Processed job id #$id\n";
    }
    $loop++;
} while (isSafeToExecute());
echo "--\nAutomatic importing looped $loop times ~ /dashboard/bulk for stats \n";
die(0);
