<?php
$translation_header = array (
  'Project-Id-Version' => 'Chevereto V3',
  'POT-Creation-Date' => '2021-07-05 14:26-0400',
  'PO-Revision-Date' => '2021-11-17 08:49-0300',
  'Last-Translator' => 'Rodolfo Berríos <inbox@rodolfoberrios.com>',
  'Language-Team' => '',
  'Language' => 'en_US',
  'MIME-Version' => '1.0',
  'Content-Type' => 'text/plain; charset=UTF-8',
  'Content-Transfer-Encoding' => '8bit',
  'X-Generator' => 'Poedit 3.0',
  'X-Poedit-Basepath' => '../../..',
  'Plural-Forms' => 'nplurals=2; plural=(n != 1);',
  'X-Poedit-KeywordsList' => '_s;_se;_n:1,2;_ne:1,2;PF.fn._s;PF.fn._n:1,2',
  'X-Poedit-SourceCharset' => 'UTF-8',
  'X-Poedit-SearchPath-0' => '.',
  'X-Poedit-SearchPathExcluded-0' => 'app/vendor',
  'X-Poedit-SearchPathExcluded-1' => 'app/content/languages/cache',
);
$translation_plural = array (
  'nplurals' => 2,
  'function' => '($n != 1)',
);
$translation_table = [
];
?>