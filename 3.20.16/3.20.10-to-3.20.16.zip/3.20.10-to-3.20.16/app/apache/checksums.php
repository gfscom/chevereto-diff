<?php return array (
  'app/.htaccess' => 'b9ac088371e0dcad02c417900069bc9b',
  'content/.htaccess' => 'b9ac088371e0dcad02c417900069bc9b',
  'images/.htaccess' => 'b9ac088371e0dcad02c417900069bc9b',
  'importing/.htaccess' => 'd984f0472c79dac505f550a24090b391',
  'lib/G/.htaccess' => 'd984f0472c79dac505f550a24090b391',
  'app/importer/jobs/.htaccess' => 'd984f0472c79dac505f550a24090b391',
);