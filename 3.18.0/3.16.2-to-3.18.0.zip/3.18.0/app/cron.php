<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
            <inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.

  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */

$loop = 1;
$jobs = ['storageDelete', 'deleteExpiredImages', 'cleanUnconfirmedUsers', 'removeDeleteLog', 'tryForUpdates'];
try {
    shuffle($jobs);
    foreach ($jobs as $job) {
        if (!CHV\isSafeToExecute()) {
            echo "Exit - (time is up)\n";
            die(0);
        }
        echo "Processing $job\n";
        $job();
    }
    $loop++;
} catch (\Exception $e) {
    echo $e->getMessage() . "\n";
    die(255);
}
die(0);

function storageDelete()
{
    $lock = new CHV\Lock('storage-delete');
    if ($lock->create()) {
        CHV\Queue::process(['type' => 'storage-delete']);
        $lock->destroy();
    }
}

function deleteExpiredImages()
{
    $lock = new CHV\Lock('delete-expired-images');
    if ($lock->create()) {
        CHV\Image::deleteExpired(50);
        $lock->destroy();
    }
}

function cleanUnconfirmedUsers()
{
    $lock = new CHV\Lock('clean-unconfirmed-users');
    if ($lock->create()) {
        CHV\User::cleanUnconfirmed(5);
        $lock->destroy();
    }
}

function removeDeleteLog()
{
    $lock = new CHV\Lock('remove-delete-log');
    if ($lock->create()) {
        $db = CHV\DB::getInstance();
        $db->query('DELETE FROM ' . CHV\DB::getTable('deletions') . ' WHERE deleted_date_gmt <= :time;');
        $db->bind(':time', G\datetime_sub(G\datetimegmt(), 'P3M'));
        $db->exec();
        $lock->destroy();
    }
}

function tryForUpdates()
{
    if (
        is_null(CHV\Settings::get('update_check_datetimegmt'))
        || G\datetime_add(CHV\Settings::get('update_check_datetimegmt'), 'P1D') < G\datetimegmt()) {
        CHV\L10n::setLocale(CHV\Settings::get('default_language'));
        $lock = new CHV\Lock('check-updates');
        if ($lock->create()) {
            CHV\checkUpdates();
            $lock->destroy();
        }
    }
}
