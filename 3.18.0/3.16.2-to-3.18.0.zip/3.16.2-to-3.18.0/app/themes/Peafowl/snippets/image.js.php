<?php if (!defined('access') or !access) {
    die('This file cannot be directly accessed.');
} ?>
<script data-cfasync="false">
    var divLoading = document.createElement("div");
    divLoading.id = "image-viewer-loading";
    divLoading.className = "soft-hidden";
    document.getElementById("image-viewer").appendChild(divLoading)
	document.getElementById("top-bar").className += ' transparent';
	image_viewer_full_fix = function() {
		var viewer = document.getElementById("image-viewer"),
            zoomable = viewer.getElementsByTagName('img')[0],
			top = document.getElementById("top-bar"),
			imgSource = {
				width: <?php echo get_image()["width"]; ?>,
				height: <?php echo get_image()["height"]; ?>
			},
			img = {width: imgSource.width, height: imgSource.height},
			ratio = imgSource.width/imgSource.height;
		var canvas = {
				height: window.innerHeight - (typeof top !== "undefined" ? top.clientHeight : 0),
				width: viewer.clientWidth
			};
		var viewer_banner_top = <?php echo CHV\getSetting('banner_image_image-viewer_top') ? 1 : 0; ?>,
			viewer_banner_foot = <?php echo CHV\getSetting('banner_image_image-viewer_foot') ? 1 : 0; ?>;
		var viewer_banner_height = 90;
		if(viewer_banner_top) {
			canvas.height -= viewer_banner_height + 20;
		}
		if(viewer_banner_foot) {
			canvas.height -= viewer_banner_height + 20;
		}
		var hasClass = function(element, cls) {
			return (" " + element.className + " ").indexOf(" " + cls + " ") > -1;
		}
		if(img.width > canvas.width) {
			img.width = canvas.width;
		}
        img.height = (img.width/ratio);
        if(zoomable.dataset.is360 == '0') {
            if(img.height > canvas.height && (img.height/img.width) < 3) {
            	img.height = canvas.height;
            }
            if(img.height == canvas.height) {
            	img.width = (img.height * ratio);
            }
            if(imgSource.width !== img.width) {
                if(img.width > canvas.width) {
                    img.width = canvas.width;
                    img.height = (img.width/ratio);
                } else if((img.height/img.width) > 3) {
                    img = imgSource;
                    if(img.width > canvas.width) {
                        img.width = canvas.width * 0.8;
                    }
                    img.height = (img.width/ratio);
                }
            }
            if(imgSource.width > img.width || img.width <= canvas.width) {
            	if(img.width == canvas.width || imgSource.width == img.width) {
            		zoomable.className = zoomable.className.replace(/\s+cursor-zoom-(in|out)\s+/, " ");
            	} else {
            		if(!hasClass(zoomable, "cursor-zoom-in")) {
            			zoomable.className += " cursor-zoom-in";
            		} else {
            			zoomable.className = zoomable.className.replace(/\s+cursor-zoom-in\s+/, " ");
                        if(!hasClass(zoomable, "cursor-zoom-in")) {
                            zoomable.className += " cursor-zoom-in";
                            styleContainer = false;
                        }
            		}
            	}
                zoomable.className = zoomable.className.trim().replace(/ +/g, ' ');
            }
        }
         img = {
            width: img.width + "px",
            height: img.height + "px",
            display: "block"
        }
        if(zoomable.style.width !== img.width) {
            for(var k in img) {
                zoomable.style[k] = img[k];
            }
        }
	}
	image_viewer_full_fix();
	document.addEventListener('DOMContentLoaded', function(event) {
		CHV.obj.image_viewer.image = {
			width: <?php echo get_image()["width"]; ?>,
			height: <?php echo get_image()["height"]; ?>,
			ratio: <?php echo number_format(get_image()['ratio'], 6, '.', ''); ?>,
			url: "<?php echo get_image()["url"]; ?>",
			medium: {
				url: "<?php echo get_image()["medium"]["url"]; ?>"
			},
            url_viewer: "<?php echo get_image()["url_viewer"]; ?>",
            is_360: <?php echo get_image()["is_360"] ? 'true' : 'false'; ?>,
		};
		CHV.obj.image_viewer.album = {
			id_encoded: "<?php echo get_image()["album"]["id_encoded"]; ?>"
		};
		image_viewer_full_fix();
		CHV.fn.image_viewer_full_fix = window["image_viewer_full_fix"];
	});
</script>