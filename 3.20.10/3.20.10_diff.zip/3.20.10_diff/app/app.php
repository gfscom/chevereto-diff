<?php

define('G_APP_NAME', 'Chevereto');
define('G_APP_VERSION', '3.20.10');
define('G_APP_VERSION_AKA', 'coqueto');