<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
            <inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.

  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */

namespace CHV;

use G;
use Exception;

class Lock
{
    private $name;

    public function __construct($name)
    {
        $this->name = $name;
    }

    public function create()
    {
        $lock = DB::get('locks', ['name' => $this->name])[0];
        if ($lock) {
            $diff = G\datetime_diff($lock['expires_gmt']);
            if ($diff < 0) {
                return false;
            }
            $this->destroy();
        }
        $datetime = G\datetimegmt();
        try {
            $insert = DB::insert('locks', [
                'name' => $this->name,
                'date_gmt' => $datetime,
                'expires_gmt' => G\datetime_add($datetime, 'PT15S'),
            ]);
            return $insert !== false;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function destroy()
    {
        if (DB::delete('locks', ['name' => $this->name]) === false) {
            throw new LockException('Unable to destroy lock ' . $this->name);
        }

        return true;
    }
}
class LockException extends Exception
{
}
