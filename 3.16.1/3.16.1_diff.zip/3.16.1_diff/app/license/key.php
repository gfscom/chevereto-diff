<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */
  
$license = 'Z6Zo:7cdfcb9b4d3d9fbd7e8cd9f65629a5285519e4c325a56e1b19b982398b51c6181b869e81bd500f7ee71ecd1464900c85069922964ea8ba86ba8acc99f348a76b';