<?php

class SEOURLify extends URLify
{
}
