<div class="list-item-desc">
	<div class="list-item-desc-title">
		<a href="%IMAGE_URL_VIEWER%" class="list-item-desc-title-link" data-text="image-title-truncated" data-content="image-link" title="%IMAGE_TITLE%">%IMAGE_TITLE%</a><span class="display-block font-size-small"><?php _se('From %s', '<a href="%IMAGE_ALBUM_URL%" data-text="album-name" data-content="album-link">%IMAGE_ALBUM_NAME_TRUNCATED%</a>'); ?></span>
	</div>
	%tpl_list_item/item_like% 
</div>